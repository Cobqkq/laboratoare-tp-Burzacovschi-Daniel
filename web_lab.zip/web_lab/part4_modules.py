# Laborator: funcții, metode și importuri pe web
# Student: <Burzacovschi Daniel>
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

from urllib.parse import urlparse
from urllib.parse import urljoin
import re
import requests
from html.parser import HTMLParser
import hashlib
import requests
import time
import json
import socket
import ssl 
import time 

# Exercițiul 35
def descompune_url(adresa):
    """Funcția descompune adresa în componentele sale și le afișează pe ecran"""
    url_descompus = urlparse(adresa)
    print("Scheme:   ", url_descompus.scheme)
    print("Netloc:   ", url_descompus.netloc)
    print("Path:     ", url_descompus.path)
    print("Query:    ", url_descompus.query)
    print("Fragment: ", url_descompus.fragment)
descompune_url("https://cybercor.org/path?x=1#top")

# Exercițiul 36
def compune_url(base, legaturi):
    """Transformă o listă de legături relative în URL-uri complete."""
    for legatura in legaturi:
        url_complet = urljoin(base, legatura)
        print(f"{legatura:15} -> {url_complet}")
rute_relative = ["/about", "contact.html", "../index.html"]
compune_url(BASE_URL, rute_relative)

# Exercițiul 37
def extract_links(html):
    """Extrage toate legăturile (href) dintr-un cod HTML și elimină duplicatele."""
    toate_legaturile = re.findall(r'href="([^"]+)"', html)
    legaturi_unice = list(set(toate_legaturile))
    return legaturi_unice
r11 = requests.get(BASE_URL, timeout=TIMEOUT)
linkuri = extract_links(r11.text)
print(f"Am găsit {len(linkuri)} legături unice:")
print(linkuri)

# Exercițiul 38
def split_links(links, domain):
    """Împarte o listă de legături în două liste: interne și externe."""
    interne = []
    externe = []
    domeniu_tinta = urlparse(domain).netloc
    
    for link in links:
        link_complet = urljoin(domain, link)
        domeniu_link = urlparse(link_complet).netloc
        if domeniu_link == domeniu_tinta:
            interne.append(link_complet)
        else:
            externe.append(link_complet)
    return interne, externe
linkuri_interne, linkuri_externe = split_links(linkuri, BASE_URL)
print(f"S-au găsit {len(linkuri_interne)} legături interne și {len(linkuri_externe)} externe.")

#Exercițiul 39
class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []
    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)
#test pe html cunoscut
test_html = """ <html><body> <img src="/logo.png" alt="Logo"> <IMG SRC="poza.jpg"> <img alt="imagine fără src"> 
<img src="https://cdn.example.com/banner.webp" /> <a href="/despre">Aceasta nu este o imagine</a> </body></html>"""

finder = ImageFinder()
finder.feed(test_html)
print("Imagini găsite în test:", finder.images)
assert finder.images == [
 "/logo.png",
 "poza.jpg", 
 "https://cdn.example.com/banner.webp", 
 ], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut cu succes!\n")
print("Scanăm site-ul real")
response = requests.get(BASE_URL, timeout=TIMEOUT)
real_finder = ImageFinder()
real_finder.feed(response.text)
print(f"{len(real_finder.images)} imagini găsite pe {BASE_URL}:")
for src in real_finder.images:
    print(" -", src)
nr_taguri_brut = response.text.lower().count("<img")
print(f"\nVerificare: {nr_taguri_brut} tag-uri <img detectate brut în textul HTML.")

# Exercițiul 40
def page_fingerprint(url):
    """Calculează amprenta criptografică (hash SHA-256) a conținutului brut al unei pagini web."""
    response = requests.get(url, timeout=TIMEOUT)
    amprenta = hashlib.sha256(response.content).hexdigest()
    return amprenta
print("Calculăm prima amprentă...")
hash_1 = page_fingerprint(BASE_URL)
print("Hash 1:", hash_1)
time.sleep(1)
print("\nCalculăm a doua amprentă...")
hash_2 = page_fingerprint(BASE_URL)
print("Hash 2:", hash_2)
if hash_1 == hash_2:
    print("Amprentele sunt identice. Conținutul paginii nu s-a schimbat absolut deloc.")
else:
    print("Amprentele sunt diferite! Ceva s-a modificat în codul paginii.")

# Exercițiul 41
def salveaza_si_incarca_json(url):
    """Salvează antetele HTTP într-un fișier JSON, le citește înapoi și afișează un antet."""
    response = requests.get(url, timeout=TIMEOUT)
    with open("headers.json", "w") as file:
        json.dump(dict(response.headers), file, indent=2)
    with open("headers.json", "r") as file:
        date_incarcate = json.load(file)
    print("Serverul folosește:", date_incarcate.get("Server", "Necunoscut"))
salveaza_si_incarca_json(BASE_URL)

# Exercițiul 42
def resolve(hostname):
    """Returnează adresa IP a unui domeniu prin interogare DNS."""
    return socket.gethostbyname(hostname)

# Apel Exercițiul 43
domeniu = urlparse(BASE_URL).netloc
ip_cybercor = resolve(domeniu)
print(f"Adresa IP pentru {domeniu} este {ip_cybercor}")

# Exercițiul 43
def cert_days_left(hostname):
    """Se conectează la portul 443 și returnează numărul de zile până la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            expirare_secunde = ssl.cert_time_to_seconds(cert["notAfter"])
            timp_curent_secunde = time.time()
            zile_ramase = (expirare_secunde - timp_curent_secunde) / 86400
            return int(zile_ramase)
        
time.sleep(1) 
zile = cert_days_left(domeniu)
print(f"Certificatul pentru {domeniu} expiră în {zile} zile.")

