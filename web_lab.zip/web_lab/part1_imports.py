# Laborator: funcții, metode și importuri pe web
# Student: <Burzacovschi Daniel>
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 

#Exercițiul 1
import requests
print(requests.__version__)
import urllib.request
#Requests a avut nevoie de pip install,deoarece este un modul extern,iar urllib nu,pentru că este un modul din biblioteca standard Python.

#Exercițiul 2
import requests
r1 = requests.get(BASE_URL,timeout=TIMEOUT)
print(r1.status_code)

from requests import get
r2 = get(BASE_URL,timeout=TIMEOUT)
print(r2.status_code)
#Un avantaj al primului stil este claritatea codului,deoarece se vede din ce modul se folosește funcția get.
#Un avantaj al celui de-al doilea stil este sintaxa mai scurtă,întrucât nu trebuie să se scrie numele modulului în fața funcției.

#Exercițiul 3
import requests as rq
rq.get(BASE_URL,timeout=TIMEOUT)
#Un alias face codul mai ușor de citit când numele modulului este lung și aliasul este sugestiv
#Îl face mai greu de citit în cazul în care aliasul nu este sugestiv. De exemplu,dacă s-ar numi x pentru modulul requests.

#Exercițiul 4
import urllib.request
request = urllib.request.Request(BASE_URL,headers={"user-agent": "Mozilla/5.0"})
r3 = urllib.request.urlopen(request,timeout=TIMEOUT)
print(r3.status)
text = r3.read()
text = text.decode("utf-8")
print(text[:200])

#Exercițiul 5
print(dir(requests))
#ConnectTimeout este o clasă 
#get este o funcție 
#structures este un modul

#Exercițiul 6 
help(requests.get)
r4 = requests.get(BASE_URL,timeout=TIMEOUT)
print(r4.status_code)

#Exercițiul 7
import time
start = time.perf_counter()
r5 = requests.get(BASE_URL,timeout=TIMEOUT)
stop = time.perf_counter()
print(stop-start)
print(r5.elapsed.total_seconds())

#Exercițiul 8
try:
    import bs4 #type:ignore
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")