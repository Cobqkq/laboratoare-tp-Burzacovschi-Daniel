# Laborator: funcții, metode și importuri pe web
# Student: <Burzacovschi Daniel>
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 

#Exercițiul 9
import requests
r1 = requests.get(BASE_URL,timeout=TIMEOUT)
print(r1.status_code)#atribut
print(r1.ok)#atribut
print(r1.url)#atribut
print(r1.encoding)#atribut

#Exercițiul 10
r2 = requests.get(BASE_URL,timeout=TIMEOUT)
r2.raise_for_status()
try:
    r3 = requests.get(BASE_URL + "/this-page-does-not-exist",timeout=TIMEOUT)
    r3.raise_for_status()
except requests.HTTPError:
    print("nu s-a putut accesa pagina")

#Exercițiul 11
r4 = requests.get(BASE_URL,timeout=TIMEOUT)
for Nume,valoare in r4.headers.items():
    print(Nume,":",valoare)

#Exercițiul 12
r5 = requests.get(BASE_URL,timeout=TIMEOUT)
print(r5.headers.get("Server","lipsește"))
print(r5.headers.get("Content-Type","lipsește"))
print(r5.headers.get("content-type","lipsește"))
#Observ că rezultatul nu s-a schimbat,indiferent de scrierea cu minuscule.

#Exercițiul 13
r6 = requests.get(BASE_URL,timeout=TIMEOUT)
print(r6.text.lower().count("cyber")) 
#Pot înlănțui metodele,deoarece metoda lower() returnează un șir de caractere,iar metoda count() 
#poate fi aplicată pe șiruri de caractere.

#Exercițiul 14
r7 = requests.get(BASE_URL,timeout=TIMEOUT)
text = r7.text
start = text.find("<title>") + len("<title>")
end = text.find("</title>")
titlu = text[start:end]
print(titlu)

#Exercițiul 15
r8 = requests.get(BASE_URL,timeout=TIMEOUT)
text = r8.text
lines = text.splitlines()
print(max(lines,key=len))
print(len(lines))

#Exercițiul 16
r9 = requests.get(BASE_URL,timeout=TIMEOUT)
url = r9.url
if url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

#Exercițiul 17
r10 = requests.get("http://cybercor.org",timeout=TIMEOUT)
for redirect in r10.history:
    print(redirect.status_code,redirect.url)
print(r10.url)

#Exercițiul 18
r11_head = requests.head(BASE_URL,timeout=TIMEOUT)
r11_get = requests.get(BASE_URL,timeout=TIMEOUT)
print(len(r11_head.content))
print(len(r11_get.content))
#len(head.content) este 0,deoarece head cere doar anteturile de la site,pe când get cere tot conținutul paginii,stocând un număr mai mare de caractere.

#Exercițiul 19
r12 = requests.get(BASE_URL,timeout=TIMEOUT)
if r12.cookies:
    for cookie in r12.cookies:
        print(cookie.name,cookie.secure)
else:
    print("Niciun cookie setat")

#Exercițiul 20
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-<Daniel>"})
r13 = session.get(ECHO_URL + "/headers",timeout=TIMEOUT)
print(r13.text)