import argparse
import csv
from datetime import datetime
from webtools import get_title, security_headers, site_report, DEFAULT_HEADERS, check_paths

def main():
    print(DEFAULT_HEADERS)

    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    args = parser.parse_args()

    rezultate = check_paths(args.url, ["/", "/robots.txt", "/sitemap.xml"])
    
    with open("report.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in rezultate.items():
            writer.writerow([path, status, datetime.now().isoformat()])
            
    site_report(args.url)

if __name__ == "__main__":
    main()