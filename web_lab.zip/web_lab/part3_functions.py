# Laborator: funcții, metode și importuri pe web
# Student: <Burzacovschi Daniel>
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

#Exercițiul 21
import requests
def fetch(url):
    """Funcția returnează obiectul răspuns"""
    r = requests.get(url,timeout=TIMEOUT)
    return r
print(fetch(BASE_URL).status_code)

#Exercițiul 22
import time
def get_status(url):
    """Funcția returnează codul de stare al răspunsului"""
    r1 = requests.get(url,timeout=TIMEOUT)
    return r1.status_code
print(get_status(BASE_URL + "/"))
time.sleep(1)
print(get_status(BASE_URL + "/robots.txt"))
time.sleep(1)
print(get_status(BASE_URL + "/sitemap.xml"))

#Exercițiul 23
def fetch(url,timeout=10):
    """Funcția returnează răspunsul,doar că timeout are valoare implicită"""
    r2 = requests.get(url,timeout=timeout)
    return r2
print(fetch(BASE_URL))
time.sleep(1)
#print(fetch(BASE_URL,timeout=3))

#Exercițiul 24
def get_title(html):
    """Funcția returnează titlul paginii"""            
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    titlu = html[start:end]
    return titlu
r3 = requests.get(BASE_URL,timeout=TIMEOUT)
print(get_title(r3.text))

#Exercițiul 25
help(get_title)

#Exercițiul 26
def get_status(url:str) -> int:
    """Funcția returnează codul de stare al răspunsului"""
    r4 = requests.get(url,timeout=TIMEOUT)
    return r4.status_code
#print(get_status(123))
#Observ că adnotarea de tip nu încurcă execuției codului,dar din cauza argumentului 123 codul a dat eroare.

#Exercițiul 27
def page_exists(url):
    """Funcția verifică dacă pagina există folosind True și False"""
    try:
        r5 = requests.get(url,timeout=TIMEOUT)
    except requests.RequestException:
        return False
    return r5.ok
print(page_exists("https://this-domain-does-not-exist.invalid"))

#Exercițiul 28
def check_paths(base,paths):
    """Funcția returnează un dicționar cu codurile de statut a rutelor paginii"""
    rezultate = {}
    for path in paths:
        url = base + path
        r6 = requests.get(url,timeout=TIMEOUT)
        rezultate[path] = r6.status_code
        time.sleep(1)
    return rezultate        
list = ["/","/robots.txt","/sitemap.xml"]
print(check_paths(BASE_URL,list))

#Exercițiul 29
def get_header(url,name,default="lipsește"):
    """Funcția returnează valoarea unui singur antet"""
    r7 = requests.get(url,timeout=TIMEOUT)
    antet = r7.headers.get(name,default)
    return antet
print(get_header(BASE_URL,name="Server"))

#Exercițiul 30
def security_headers(url):
    """Funcția returnează valoare booleană pentu prezența antetelor de securitate de pe pagină"""
    anteteSecuritate = ["Strict-Transport-Security","Content-Security-Policy","X-Frame-Options","X-Content-Type-Options","Referrer-Policy"]
    dictionar = {}
    r8 = requests.get(url,timeout=TIMEOUT)
    for header in anteteSecuritate:
        dictionar[header] = header in r8.headers
    return dictionar
print(security_headers(BASE_URL))

#Exercițiul 31
def score_headers(results):
    """Funcția returnează numărul de antete de securitate de pe pagină"""
    scor = 0
    for value in results.values():
        if value == True:
            scor += 1
    return f"{scor}/5"
print(score_headers(security_headers(BASE_URL)))

#Exercițiul 32
def fetch_robots(base):
    """Funcția returnează True/False dacă există pagina /robots.txt"""
    url = base + "/robots.txt"
    r9 = requests.get(url,timeout=TIMEOUT)
    if r9.ok:
        return r9.text
    else:
        return None

def disallowed_paths(robots_text):
    """Funcția returnează căile care au setat disallow"""
    if robots_text == None:
        return[]
    paths = []
    for line in robots_text.splitlines():
        if "Disallow" in line:
            elemente = line.split()
            if len(elemente) > 1:
                clearPaths = elemente[1]
                paths.append(clearPaths)
    return paths

print(disallowed_paths(fetch_robots(BASE_URL)))

#Exercițiul 33
def response_times(*urls):
    """Funcția returnează dicționare cu pagina accesată și timpul în care a fost trimisă cererea"""
    timp = {}
    for url in urls:
        r10 = requests.get(url,timeout=TIMEOUT)
        timp[url] = r10.elapsed.total_seconds()
        time.sleep(1)
    return timp
print(response_times(BASE_URL, ECHO_URL))

#Exercițiul 34
def log(message,**details):
    """Funcția returnează mesajul urmmat de fiecare detaliu"""
    result = message
    for cheie,valoare in details.items():
        result = result + f" | {cheie}={valoare}"
    print(result)
log("verificat", url=BASE_URL, status=200)