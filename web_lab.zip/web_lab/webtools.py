import requests
import time
import json
import socket
import ssl
import re
from urllib.parse import urlparse, urljoin

TIMEOUT = 10

# Exercițiul 47
DEFAULT_HEADERS = {"User-Agent": "WebLab-Student"}

#Exercițiul 44
def fetch(url):
    """Descarcă o pagină web folosind antetele implicite."""
    # Exercițiul 47
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)

def get_status(url):
    """Returnează codul de stare HTTP."""
    return fetch(url).status_code

def get_title(html):
    """Extrage titlul paginii."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    if start != -1 and end != -1:
        return html[start:end].strip()
    return "Fără titlu"

def security_headers(url):
    """Verifică prezența a cinci antete de securitate (Ex. 30)."""
    headers_to_check = [
        "Strict-Transport-Security", "Content-Security-Policy",
        "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"
    ]
    response = fetch(url)
    return {h: (h in response.headers) for h in headers_to_check}

def score_headers(results):
    """Returnează scorul antetelor (Ex. 31)."""
    scor = sum(1 for v in results.values() if v)
    return f"{scor}/{len(results)}"

def resolve(hostname):
    """Află adresa IP."""
    return socket.gethostbyname(hostname)

def cert_days_left(hostname):
    """Zile până la expirarea SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            return int((ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) / 86400)

def extract_links(html):
    """Extrage legăturile fără duplicate."""
    return list(set(re.findall(r'href="([^"]+)"', html)))

def split_links(links, domain):
    """Împarte legăturile în interne și externe."""
    domeniu_tinta = urlparse(domain).netloc
    interne, externe = [], []
    for link in links:
        link_complet = urljoin(domain, link)
        if urlparse(link_complet).netloc == domeniu_tinta:
            interne.append(link_complet)
        else:
            externe.append(link_complet)
    return interne, externe

def fetch_robots(base):
    resp = fetch(urljoin(base, "/robots.txt"))
    return resp.text if resp.ok else None

def disallowed_paths(robots_text):
    if not robots_text: return []
    return [line.split(": ")[1].strip() for line in robots_text.splitlines() if line.startswith("Disallow:")]

def check_paths(base, paths):
    """Returnează un dicționar {path: status_code} pentru Ex 49."""
    rezultat = {}
    for p in paths:
        time.sleep(1)
        rezultat[p] = get_status(urljoin(base, p))
    return rezultat

# Exercițiul 50
def site_report(url):
    """Colectează informațiile, le afișează și le salvează în report.json."""
    print(f"Raport site: {url}")
    
    resp = fetch(url)
    domeniu = urlparse(url).netloc
    
    print(f"Cod de stare:      {resp.status_code}")
    titlu = get_title(resp.text)
    print(f"Titlu:             {titlu}")
    ip = resolve(domeniu)
    print(f"Adresă IP:         {ip}")
    
    http_url = url.replace("https://", "http://")

    time.sleep(1)
    resp_http = fetch(http_url)
    redir = f"{resp_http.history[0].status_code} -> {resp_http.url}" if resp_http.history else "Niciuna"
    print(f"Redirecționări:    {redir}")
    
    time.sleep(1)
    scor = score_headers(security_headers(url))
    print(f"Scor securitate:   {scor}")
    
    zile = cert_days_left(domeniu)
    print(f"Certificat:        {zile} de zile rămase")
    
    linkuri = extract_links(resp.text)
    interne, externe = split_links(linkuri, url)
    print(f"Legături:          {len(interne)} interne, {len(externe)} externe")
    
    time.sleep(1)
    cai = disallowed_paths(fetch_robots(url))
    print(f"Căi interzise:     {', '.join(cai) if cai else 'Niciuna'}")
    raport = {
        "status_code": resp.status_code, "title": titlu, "ip": ip, "redirects": redir,
        "security_score": scor, "cert_days": zile, "links_in": len(interne),
        "links_out": len(externe), "disallowed": cai
    }
    with open("report.json", "w") as f:
        json.dump(raport, f, indent=4)
    print("Salvat în report.json")

# Exercițiul 46
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
    # Autotestul rulează doar direct (python webtools.py) deoarece variabila specială 
    # name devine "main" doar în fișierul principal. Când modulul e importat 
    # în main.py, valoarea lui name este "webtools", deci codul din acest IF este ignorat.